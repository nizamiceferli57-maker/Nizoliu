"""Render.com ucun balaca HTTP server.

Render-in pulsuz plani YALNIZ 'Web Service' tipini dastekleyir, bu da bir PORT-u
dinlemeyi teleb edir - yoxsa Render botu 'canli' saymir ve yatirir/yixir.

Bu server botun esas isi (Telegram + TikTok) ile PARALEL, ayri bir thread-de
islayir ve ona heç toxunmur - sadece '/' ucun "OK" qaytarir.

Yalniz PORT env deyiseni varsa ise dusur (Render bunu avtomatik qoyur).
Termux/lokal kompyuterde PORT yoxdur -> bu modul heç ne etmir.
"""
import os
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer


class _Health(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"OK - tiktok bot isleyir (Telegram ustunden idare olunur)")

    def log_message(self, *args) -> None:  # noqa: D401 - konsolu HTTP log-u ile doldurmasin
        pass


def start_if_needed() -> None:
    """Render-de (PORT varsa) balaca HTTP serveri arxa fonda baslat; basqa yerde heç ne etme."""
    port_raw = os.environ.get("PORT", "").strip()
    if not port_raw:
        return
    try:
        port = int(port_raw)
    except ValueError:
        return
    srv = HTTPServer(("0.0.0.0", port), _Health)
    t = threading.Thread(target=srv.serve_forever, name="render-health", daemon=True)
    t.start()
    print(f"[RENDER] saglamliq server {port} portunda isleyir (Render bunu 'canli' sayir)", flush=True)
