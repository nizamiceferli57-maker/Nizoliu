"""Kohne (Termux-da qalmis) istifadeci siyahisini bu bot qovluğundaki users_base.txt ile birlesdirir.

Istifade (bot qovluğunda, Termux-da):
    python merge_old_users.py /path/to/kohne_fayl.txt [daha_bir_fayl.txt ...]

Nece isleyir:
  - Movcud users_base.txt (burada artiq hazirlanmis 14313 adlik siyahi) BASDA qalir, SIRASI deyismir.
  - Her kohne faylda olan, amma users_base.txt-de OLMAYAN adlar axira elave olunur (boyuk/kicik herf ferqi yoxdur).
  - Netice yeniden users_base.txt-e yazilir (ehtiyat nusxe: users_base.txt.bak).
  - Bot novbeti defe baslayanda (users.txt yoxdursa) bu faylı istifade edecek.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "users_base.txt"


def clean(name: str) -> str | None:
    name = name.strip().lstrip("@").strip()
    if not name or name.startswith("#"):
        return None
    return name


def main() -> None:
    if not sys.argv[1:]:
        sys.exit("Istifade: python merge_old_users.py /path/to/kohne_fayl.txt [daha fayllar...]")

    existing_raw = DEST.read_text(encoding="utf-8", errors="ignore").splitlines() if DEST.exists() else []
    existing = []
    seen = set()
    for line in existing_raw:
        n = clean(line)
        if n and n.lower() not in seen:
            seen.add(n.lower())
            existing.append(n)

    added = []
    for arg in sys.argv[1:]:
        p = Path(arg).expanduser()
        if not p.exists():
            print(f"  ⚠ tapılmadı: {p}")
            continue
        n_before = len(added)
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            n = clean(line)
            if n and n.lower() not in seen:
                seen.add(n.lower())
                added.append(n)
        print(f"  ✅ {p.name}: +{len(added) - n_before} yeni ad")

    if DEST.exists():
        DEST.replace(DEST.with_suffix(".txt.bak"))

    merged = existing + added
    DEST.write_text("\n".join(merged) + "\n", encoding="utf-8")
    print(f"=== users_base.txt: cəmi {len(merged)} ad (əvvəlki {len(existing)} + yeni {len(added)}) ===")


if __name__ == "__main__":
    main()
