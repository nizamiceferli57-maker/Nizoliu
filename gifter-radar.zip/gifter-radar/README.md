# Hədiyyə Radarı

TikTok canlılarını siyahısız tapır, onlara qoşulur, hədiyyə hadisələrini dinləyir və ən çox hədiyyə göndərənlərin reytinqini yığır. Panel + istəyə görə Telegram.

## Necə işləyir
1. `src/discover.js` Playwright ilə `tiktok.com/live` səhifəsini açıb skrol edir və `@istifadəçi/live` linklərini toplayır.
2. `src/tracker.js` tapılan canlılara `tiktok-live-connector` ilə qoşulur (eyni anda `MAX_STREAMS` qədər), `gift` hadisələrini sayır.
3. `src/store.js` hər göndərəni `userId` ilə `data/gifters.json`-da toplayır: cəmi 💎, hədiyyə sayı, neçə fərqli yayımçıya göndərib.
4. `src/index.js` panel və API verir. `src/telegram.js` `/top`, `/davamli`, `/status` komandalarını verir.

## Quraşdırma (PC / VPS)
```
npm install
npx playwright install chromium
cp .env.example .env
npm start
```
Panel: http://localhost:3000 (`PANEL_KEY` yazsan: `/?key=PAROL`).

## Termux
Playwright-in öz Chromium-u Android-də işləmir. Sistem Chromium quraşdırıb `.env`-də `CHROMIUM_PATH` yaz, yaxud skanı PC/VPS-də işlət.
```
pkg install nodejs
npm install
```

## Qeydlər
- TikTok-un rəsmi açıq «canlı axtarışı» API-si yoxdur. Skan səhifənin quruluşuna bağlıdır, TikTok dəyişdirsə və ya bot yoxlaması çıxarsa `discover.js` yenilənməlidir. Boş qayıdarsa `HEADLESS=false` ilə yoxla.
- Eyni IP-dən çox canlıya qoşulmaq limitə düşə bilər, `MAX_STREAMS`-i kiçik tut.
- Reytinq yalnız botun qoşulduğu yayımları əhatə edir və zaman keçdikcə dəqiqləşir.
- Toplanan məlumat başqalarının hesab adlarıdır. Yalnız şəxsi analiz üçün işlət, yaymağa və ya satmağa çalışma.
