const { chromium } = require('playwright');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const URLS = (process.env.DISCOVER_URLS || 'https://www.tiktok.com/live').split(',').map(s => s.trim()).filter(Boolean);

// tiktok.com/live səhifəsini skan edib @istifadəçi/live linklərini toplayır
async function discover(max = 80) {
  const browser = await chromium.launch({
    headless: process.env.HEADLESS !== 'false',
    executablePath: process.env.CHROMIUM_PATH || undefined,
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });
  const found = new Set();
  try {
    const ctx = await browser.newContext({ userAgent: UA, locale: 'en-US', viewport: { width: 1280, height: 900 } });
    const page = await ctx.newPage();
    for (const url of URLS) {
      try {
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
        await page.waitForTimeout(4000);
        for (let i = 0; i < 8 && found.size < max; i++) {
          const hrefs = await page.$$eval('a[href]', as => as.map(a => a.getAttribute('href') || ''));
          for (const h of hrefs) {
            const m = h.match(/@([\w.]+)\/live/);
            if (m) found.add(m[1].toLowerCase());
          }
          await page.mouse.wheel(0, 2500);
          await page.waitForTimeout(1500);
        }
      } catch (e) {
        console.log('[discover] xəta:', url, e.message);
      }
    }
  } finally {
    await browser.close().catch(() => {});
  }
  return [...found].slice(0, max);
}

module.exports = { discover };
