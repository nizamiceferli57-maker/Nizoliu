const { WebcastPushConnection } = require('tiktok-live-connector');
const store = require('./store');
const { discover } = require('./discover');

const MAX = +process.env.MAX_STREAMS || 12;
const EVERY = (+process.env.DISCOVER_EVERY || 120) * 1000;

const live = new Map();      // username -> { conn, since, gifts, diamonds, viewers }
const cooldown = new Map();  // username -> qoşulmanın yenidən cəhd vaxtı
const state = { lastScan: null, lastFound: 0, scanning: false, error: null };

async function join(username) {
  const conn = new WebcastPushConnection(username);
  const info = { conn, since: Date.now(), gifts: 0, diamonds: 0, viewers: 0 };
  live.set(username, info);

  const drop = (why) => {
    if (!live.has(username)) return;
    live.delete(username);
    cooldown.set(username, Date.now() + 10 * 60 * 1000);
    try { conn.disconnect(); } catch (_) {}
    console.log(`[-] @${username} çıxarıldı (${why})`);
  };

  conn.on('gift', d => {
    // Seriyalı hədiyyədə yalnız seriya bitəndə say
    if (d.giftType === 1 && !d.repeatEnd) return;
    const count = d.repeatCount || 1;
    const diamonds = (d.diamondCount || 0) * count;
    if (!diamonds) return;
    info.gifts += count; info.diamonds += diamonds;
    store.addGift(
      { userId: d.userId, uniqueId: d.uniqueId, nickname: d.nickname },
      username, d.giftName || 'gift', diamonds, count
    );
  });
  conn.on('roomUser', d => { info.viewers = d.viewerCount || info.viewers; });
  conn.on('streamEnd', () => drop('yayım bitdi'));
  conn.on('disconnected', () => drop('bağlantı kəsildi'));
  conn.on('error', () => {});

  try {
    await conn.connect();
    console.log(`[+] @${username} qoşuldu (${live.size}/${MAX})`);
  } catch (e) {
    drop('qoşulmaq alınmadı');
  }
}

async function scan() {
  if (state.scanning) return;
  state.scanning = true; state.error = null;
  try {
    const names = await discover(100);
    state.lastScan = Date.now(); state.lastFound = names.length;
    console.log(`[scan] ${names.length} canlı tapıldı`);
    const now = Date.now();
    for (const n of names) {
      if (live.size >= MAX) break;
      if (live.has(n) || (cooldown.get(n) || 0) > now) continue;
      await join(n);
      await new Promise(r => setTimeout(r, 800));
    }
  } catch (e) {
    state.error = e.message;
    console.log('[scan] xəta:', e.message);
  } finally {
    state.scanning = false;
  }
}

function start() {
  scan();
  setInterval(scan, EVERY);
}

const status = () => ({
  ...state, max: MAX,
  streams: [...live.entries()].map(([name, i]) => ({
    name, since: i.since, gifts: i.gifts, diamonds: i.diamonds, viewers: i.viewers
  })).sort((a, b) => b.diamonds - a.diamonds)
});

module.exports = { start, status, scan };
