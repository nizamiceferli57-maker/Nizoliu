const fs = require('fs');
const path = require('path');
// .env faylını əl ilə oxu (əlavə paket lazım olmasın)
try {
  for (const line of fs.readFileSync(path.join(__dirname, '..', '.env'), 'utf8').split('\n')) {
    if (line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  }
} catch (_) {}

const express = require('express');
const store = require('./store');
const tracker = require('./tracker');
const telegram = require('./telegram');

const app = express();
const KEY = process.env.PANEL_KEY;

app.use('/api', (req, res, next) => {
  if (KEY && req.query.key !== KEY) return res.status(401).json({ error: 'açar səhvdir' });
  next();
});
app.get('/api/top', (req, res) => res.json(store.top({
  sort: req.query.sort === 'streamers' ? 'streamers' : 'diamonds',
  limit: Math.min(+req.query.limit || 50, 200),
  minStreamers: +req.query.min || 0
})));
app.get('/api/streamers', (req, res) => res.json(store.streamers(30)));
app.get('/api/status', (req, res) => res.json({ ...tracker.status(), totals: store.stats() }));
app.post('/api/scan', (req, res) => { tracker.scan(); res.json({ ok: true }); });
app.use(express.static(path.join(__dirname, '..', 'public')));

const port = +process.env.PORT || 3000;
app.listen(port, () => console.log(`Panel: http://localhost:${port}`));

tracker.start();
telegram.start();
process.on('SIGINT', () => { store.save(); process.exit(0); });
process.on('SIGTERM', () => { store.save(); process.exit(0); });
