const store = require('./store');
const tracker = require('./tracker');
const TOKEN = process.env.TG_TOKEN;
const ALLOWED = process.env.TG_CHAT_ID;

async function api(method, body) {
  const r = await fetch(`https://api.telegram.org/bot${TOKEN}/${method}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body)
  });
  return r.json();
}

function topText(sort) {
  const rows = store.top({ sort, limit: 15 });
  if (!rows.length) return 'Hələ məlumat yoxdur. Bot canlılara qoşulub hədiyyə yığır.';
  return rows.map((r, i) =>
    `${i + 1}. @${r.uniqueId} — ${r.diamonds.toLocaleString()} 💎, ${r.streamers} yayımçı`
  ).join('\n');
}

async function handle(msg) {
  const chat = String(msg.chat.id);
  if (ALLOWED && chat !== String(ALLOWED)) return;
  const t = (msg.text || '').trim();
  let out = null;
  if (t.startsWith('/top')) out = 'Ən çox hədiyyə göndərənlər:\n' + topText('diamonds');
  else if (t.startsWith('/davamli')) out = 'Ən çox fərqli yayımçıya göndərənlər:\n' + topText('streamers');
  else if (t.startsWith('/status')) {
    const s = tracker.status(), st = store.stats();
    out = `Aktiv yayım: ${s.streams.length}/${s.max}\nTapılan: ${s.lastFound}\nİstifadəçi: ${st.users}\nCəmi: ${st.diamonds.toLocaleString()} 💎`;
  } else if (t.startsWith('/start')) out = 'Komandalar: /top, /davamli, /status';
  if (out) await api('sendMessage', { chat_id: chat, text: out });
}

async function start() {
  if (!TOKEN) return;
  console.log('[telegram] bot işə düşdü');
  let offset = 0;
  for (;;) {
    try {
      const r = await api('getUpdates', { offset, timeout: 30 });
      for (const u of r.result || []) {
        offset = u.update_id + 1;
        if (u.message) await handle(u.message);
      }
    } catch (_) { await new Promise(r => setTimeout(r, 5000)); }
  }
}

module.exports = { start };
