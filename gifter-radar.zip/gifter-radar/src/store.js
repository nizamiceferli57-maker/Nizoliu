const fs = require('fs');
const path = require('path');
const FILE = path.join(__dirname, '..', 'data', 'gifters.json');

let db = { users: {}, streamers: {}, totals: { diamonds: 0, gifts: 0 }, since: Date.now() };
try { db = { ...db, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch (_) {}

let timer = null;
function save() {
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    fs.writeFile(FILE, JSON.stringify(db), () => {});
  }, 3000);
}

function addGift(sender, streamer, giftName, diamonds, count) {
  const key = String(sender.userId || sender.uniqueId);
  const now = Date.now();
  const u = db.users[key] || (db.users[key] = {
    uniqueId: sender.uniqueId, nickname: sender.nickname, diamonds: 0, gifts: 0,
    first: now, last: now, streamers: {}, top: {}
  });
  u.uniqueId = sender.uniqueId || u.uniqueId;
  u.nickname = sender.nickname || u.nickname;
  u.diamonds += diamonds;
  u.gifts += count;
  u.last = now;
  u.streamers[streamer] = (u.streamers[streamer] || 0) + diamonds;
  u.top[giftName] = (u.top[giftName] || 0) + count;

  const s = db.streamers[streamer] || (db.streamers[streamer] = { diamonds: 0, gifts: 0, last: now });
  s.diamonds += diamonds; s.gifts += count; s.last = now;

  db.totals.diamonds += diamonds;
  db.totals.gifts += count;
  save();
}

function top({ sort = 'diamonds', limit = 50, minStreamers = 0 } = {}) {
  const rows = Object.entries(db.users).map(([id, u]) => ({
    id, uniqueId: u.uniqueId, nickname: u.nickname, diamonds: u.diamonds, gifts: u.gifts,
    streamers: Object.keys(u.streamers).length, last: u.last,
    favorite: Object.entries(u.streamers).sort((a, b) => b[1] - a[1])[0]?.[0] || null
  })).filter(r => r.streamers >= minStreamers);
  rows.sort((a, b) => sort === 'streamers'
    ? b.streamers - a.streamers || b.diamonds - a.diamonds
    : b.diamonds - a.diamonds);
  return rows.slice(0, limit);
}

function streamers(limit = 30) {
  return Object.entries(db.streamers)
    .map(([name, s]) => ({ name, ...s }))
    .sort((a, b) => b.diamonds - a.diamonds).slice(0, limit);
}

const stats = () => ({ ...db.totals, users: Object.keys(db.users).length, since: db.since });

module.exports = { addGift, top, streamers, stats, save: () => fs.writeFileSync(FILE, JSON.stringify(db)) };
